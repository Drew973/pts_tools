# -*- coding: utf-8 -*-
"""
Created on Tue May  3 12:10:45 2022

@author: Drew.Bennett
"""

from PyQt5.QtCore import QDateTime

def parseRow(row,f_line):
    return {'start_ch':0.1*f_line,
            'end_ch':0.1*f_line+0.1,
            'raw_ch':float(row[0]),
            'time':QDateTime.fromString(row[1],'dd/MM/yyyy hh:mm:ss'),
            'rl':float(row[2]),
            'start_lon':float(row[12]),
            'start_lat':float(row[13]),
            'end_lon':float(row[14]),
            'end_lat':float(row[15]),
            'id':f_line}



def parseReadings(f):
    
    with open(f,'r',encoding='utf-8',errors='ignore') as f:
        i = 0
        startLine = None
        
        for line in f.readlines():
            row = line.lower().strip().split('\t')
                        
            if not startLine is None:
                yield parseRow(row,i-startLine)
                
            if isHeaderRow(row):
                startLine = i+1
           
            i+=1
           
              
                
              
def isHeaderRow(row):
    if row==['position km', 'date / time', 'rl', 'rl min', 'rl max', 'rl std dev', 'rl % pass', 'marker', 'temperature c', 'humidity rh', 'speed km/h', 'reference', 'gps long start', 'gps lat start', 'gps long', 'gps lat', 'files']:
        return True
    
    
    
