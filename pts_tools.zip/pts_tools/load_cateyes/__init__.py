# -*- coding: utf-8 -*-
"""
Created on Mon Oct 10 16:04:33 2022

@author: Drew.Bennett
"""

import os

test_file = os.path.join(os.path.dirname(__file__),'test.csv')

