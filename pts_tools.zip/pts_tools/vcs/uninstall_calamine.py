import subprocess
c = 'pip uninstall python-calamine'
subprocess.run(c)