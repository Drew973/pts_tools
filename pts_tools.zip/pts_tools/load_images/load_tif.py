uri = "E:/Geodata/qgis_sample_data/raster/SR_50M_alaska_nad.tif"
rlayer = iface.addRasterLayer(uri,"my raster","gdal")
#filepath,name,provider